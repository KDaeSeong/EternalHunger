// client/src/app/events/page.js (수정 기능 추가 버전)
'use client';

import { useState, useEffect } from 'react';
import axios from 'axios';
import Link from 'next/link';
import '../../styles/ERCharacters.css'; 

export default function EventsPage() {
  const [events, setEvents] = useState([]);
  const [newEvent, setNewEvent] = useState({ text: "", type: "normal" });

  // ★ 수정 모드 관리용 상태 (어떤 이벤트를 수정 중인지)
  const [editingId, setEditingId] = useState(null);
  const [editForm, setEditForm] = useState({ text: "", type: "normal" });

  // 1. 이벤트 목록 불러오기
  useEffect(() => {
    fetchEvents();
  }, []);

  const fetchEvents = async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/events');
      setEvents(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  // 2. 이벤트 추가하기
  const addEvent = async () => {
    if (!newEvent.text) return alert("내용을 입력해주세요!");
    try {
      await axios.post('http://localhost:5000/api/events/add', newEvent);
      fetchEvents(); 
      setNewEvent({ text: "", type: "normal" }); 
    } catch (err) {
      alert("추가 실패!");
    }
  };

  // 3. 이벤트 삭제하기
  const deleteEvent = async (id) => {
    if (!confirm("정말 삭제하시겠습니까?")) return;
    try {
      await axios.delete(`http://localhost:5000/api/events/${id}`);
      fetchEvents();
    } catch (err) {
      console.error(err);
      alert("삭제 실패! (서버 로그 확인)");
    }
  };

  // 4. ★ 수정 모드 진입
  const startEditing = (evt) => {
    setEditingId(evt._id); // 수정할 놈 ID 기억
    setEditForm({ text: evt.text, type: evt.type }); // 기존 내용 복사해서 입력창에 채우기
  };

  // 5. ★ 수정 취소
  const cancelEditing = () => {
    setEditingId(null);
    setEditForm({ text: "", type: "normal" });
  };

  // 6. ★ 수정 사항 저장
  const saveEdit = async (id) => {
    try {
      await axios.put(`http://localhost:5000/api/events/${id}`, editForm);
      setEditingId(null); // 수정 모드 종료
      fetchEvents(); // 목록 갱신
    } catch (err) {
      console.error(err);
      alert("수정 실패!");
    }
  };

  // 예제 불러오기
  const loadExamples = async () => {
    if (!confirm("기본 예제들을 추가하시겠습니까?")) return;
    const examples = [
      { text: "{1}이(가) 풀숲에서 잠을 잡니다.", type: "normal" },
      { text: "{1}이(가) {2}에게 짱돌을 던졌습니다.", type: "normal" },
      { text: "{1}이(가) 지뢰를 밟고 사망했습니다.", type: "death" },
      { text: "{1}이(가) {2}를 배신하고 처치했습니다!", type: "death" },
    ];
    for (const ex of examples) {
      await axios.post('http://localhost:5000/api/events/add', ex);
    }
    fetchEvents();
  };

  return (
    <main>
      <header>
        <section id="header-id1">
          <ul>
            <li>
              <Link href="/" className="logo-btn">
                <div className="text-logo">
                    <span className="logo-top">PROJECT</span>
                    <span className="logo-main">ARENA</span>
                </div>
              </Link>
            </li>
            <li><Link href="/">메인</Link></li>
            <li><Link href="/characters">캐릭터 설정</Link></li>
            <li><Link href="/details">캐릭터 상세설정</Link></li>
            <li><Link href="/events" id="EREvent">이벤트 설정</Link></li>
            <li><Link href="/modifiers">보정치 설정</Link></li>
            <li><Link href="/simulation" style={{color:'#0288d1'}}>▶ 게임 시작</Link></li>
            {/* ★ 우측 끝에 로그인/유저 정보 추가 */}
            <li className="auth-menu">
              {typeof window !== 'undefined' && localStorage.getItem('user') ? (
                <Link href="/mypage">👤 {JSON.parse(localStorage.getItem('user')).username}</Link>
              ) : (
                <Link href="/login" className="login-link">🔑 로그인</Link>
              )}
            </li>
          </ul>
        </section>
      </header>

      <div className="page-header">
        <h1>이벤트(시나리오) 설정</h1>
        <p>게임 중에 발생할 사건들을 정의합니다.</p>
      </div>

      <div style={{maxWidth: '900px', margin: '0 auto'}}>
        
        {/* 상단 입력 폼 (추가용) */}
        <div style={{
            background: 'white', padding: '20px', borderRadius: '15px', 
            display: 'flex', gap: '10px', flexWrap: 'wrap',
            boxShadow: '0 5px 15px rgba(0,0,0,0.05)', marginBottom: '30px'
        }}>
          <select 
            value={newEvent.type} 
            onChange={(e) => setNewEvent({...newEvent, type: e.target.value})}
            style={{
                padding: '10px', borderRadius: '8px', border: '1px solid #ddd',
                backgroundColor: 'white', color: '#333', fontSize: '1rem', minWidth: '120px', fontWeight: 'bold'
            }}
          >
            <option value="normal">일반 (생존)</option>
            <option value="death">💀 사망</option>
          </select>
          
          <input 
            type="text" 
            placeholder="예: {1}이(가) {2}에게 짱돌을 던졌습니다." 
            value={newEvent.text}
            onChange={(e) => setNewEvent({...newEvent, text: e.target.value})}
            style={{flexGrow: 1, padding: '10px', borderRadius: '8px', border: '1px solid #ddd', minWidth: '250px'}}
          />
          <button onClick={addEvent} style={{padding: '10px 20px', background: '#4185b3', color: 'white', border: 'none', borderRadius: '8px', cursor: 'pointer', fontWeight: 'bold'}}>
            추가
          </button>
        </div>

        {/* 이벤트 리스트 */}
        <div style={{display: 'flex', flexDirection: 'column', gap: '10px'}}>
          {events.map(evt => (
            <div key={evt._id} style={{
              background: editingId === evt._id ? '#e3f2fd' : (evt.type === 'death' ? '#fff0f0' : 'white'),
              padding: '15px', borderRadius: '10px', border: '1px solid #eee',
              borderLeft: editingId === evt._id ? '5px solid #2196f3' : (evt.type === 'death' ? '5px solid #ff5252' : '5px solid #4caf50'),
              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
              boxShadow: '0 2px 5px rgba(0,0,0,0.02)'
            }}>
              
              {/* ★ 수정 모드일 때 vs 아닐 때 화면 다르게 보여주기 */}
              {editingId === evt._id ? (
                // [수정 모드 화면]
                <div style={{display: 'flex', gap: '10px', flexGrow: 1, flexWrap: 'wrap', alignItems:'center'}}>
                   <select 
                      value={editForm.type}
                      onChange={(e) => setEditForm({...editForm, type: e.target.value})}
                      style={{padding: '8px', borderRadius: '5px', border: '1px solid #aaa'}}
                   >
                      <option value="normal">일반</option>
                      <option value="death">💀 사망</option>
                   </select>
                   <input 
                      type="text" 
                      value={editForm.text}
                      onChange={(e) => setEditForm({...editForm, text: e.target.value})}
                      style={{flexGrow: 1, padding: '8px', borderRadius: '5px', border: '1px solid #aaa'}}
                   />
                   <div style={{display:'flex', gap:'5px'}}>
                     <button onClick={() => saveEdit(evt._id)} style={{background: '#4caf50', color: 'white', border: 'none', padding: '8px 15px', borderRadius: '5px', cursor: 'pointer', fontWeight:'bold'}}>저장</button>
                     <button onClick={cancelEditing} style={{background: '#9e9e9e', color: 'white', border: 'none', padding: '8px 15px', borderRadius: '5px', cursor: 'pointer', fontWeight:'bold'}}>취소</button>
                   </div>
                </div>
              ) : (
                // [일반 보기 화면]
                <>
                  <div style={{display:'flex', alignItems:'center', gap:'10px', flexGrow: 1}}>
                      <span style={{
                          fontSize: '0.8rem', padding: '3px 8px', borderRadius: '4px', 
                          background: evt.type === 'death' ? '#ffcdd2' : '#c8e6c9',
                          color: evt.type === 'death' ? '#b71c1c' : '#1b5e20', fontWeight: 'bold'
                      }}>
                        {evt.type === 'death' ? '💀 사망' : '일반'}
                      </span>
                      <span style={{color: '#333', fontWeight: '500', fontSize:'1.05rem'}}>
                        {evt.text}
                      </span>
                  </div>

                  <div style={{display:'flex', gap:'8px'}}>
                    {/* 수정 버튼 */}
                    <button onClick={() => startEditing(evt)} style={{background: '#e0e0e0', color: '#555', border: 'none', padding: '5px 12px', borderRadius: '5px', cursor: 'pointer', fontWeight:'bold', fontSize:'0.9rem'}}>
                      ✏️ 수정
                    </button>
                    {/* 삭제 버튼 */}
                    <button onClick={() => deleteEvent(evt._id)} style={{background: '#ff5252', color: 'white', border: 'none', padding: '5px 12px', borderRadius: '5px', cursor: 'pointer', fontWeight:'bold', fontSize:'0.9rem'}}>
                      삭제
                    </button>
                  </div>
                </>
              )}

            </div>
          ))}
        </div>

        <div style={{textAlign: 'center', margin: '40px 0'}}>
             <button onClick={loadExamples} style={{background: '#ff9800', color: 'white', border: 'none', padding: '10px 20px', borderRadius: '20px', cursor: 'pointer', fontWeight: 'bold'}}>
                📂 기본 예제 불러오기
             </button>
        </div>

      </div>
    </main>
  );
}