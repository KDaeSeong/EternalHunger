// client/src/app/modifiers/page.js
'use client';

import { useState, useEffect } from 'react';
import axios from 'axios';
import Link from 'next/link';
import '../../styles/ERModifiers.css';

export default function ModifiersPage() {
  // 스탯 가중치 상태 (기본값은 모두 1.0)
  const [weights, setWeights] = useState({
    str: 1.0, agi: 1.0, int: 1.0, men: 1.0,
    luk: 1.0, dex: 1.0, sht: 1.0, end: 1.0
  });

  // 1. 서버에서 기존 설정 불러오기
  useEffect(() => {
    axios.get('http://localhost:5000/api/settings')
      .then(res => {
        if (res.data.statWeights) {
          setWeights(res.data.statWeights);
        }
      })
      .catch(err => console.error("로드 실패:", err));
  }, []);

  // 2. 값 변경 핸들러
  const handleChange = (key, value) => {
    setWeights(prev => ({ ...prev, [key]: parseFloat(value) }));
  };

  // 3. 저장
  const saveSettings = async () => {
    if (!window.confirm("이 밸런스로 게임을 진행하시겠습니까?")) return;
    try {
      await axios.post('http://localhost:5000/api/settings/save', { statWeights: weights });
      alert("⚖️ 밸런스 패치 완료!");
    } catch (err) {
      alert("저장 실패!");
    }
  };

  // 스탯 라벨 매핑
  const statLabels = {
    str: '근력 (공격력)', agi: '민첩 (선공권)', int: '지능 (변수창출)', men: '정신 (저항력)',
    luk: '행운 (생존변수)', dex: '손재주 (정확도)', sht: '사격 (견제력)', end: '지구력 (방어력)'
  };

  return (
    <main>
      <header>
        <section id="header-id1">
          <ul>
            {/* ▼ 로고 부분 교체 (className="logo-btn" 필수!) */}
            <li>
              <Link href="/" className="logo-btn">
                <div className="text-logo">
                  <span className="logo-top">PROJECT</span>
                  <span className="logo-main">ARENA</span>
                </div>
              </Link>
            </li>
            
            <li><Link href="/">메인</Link></li>
            <li><Link href="/characters">캐릭터 설정</Link></li>
            <li><Link href="/details">캐릭터 상세설정</Link></li>
            <li><Link href="/events">이벤트 설정</Link></li>
            <li><Link href="/modifiers">보정치 설정</Link></li>
            
            {/* ▼ 게임 시작 버튼 스타일 (파란색 강조) */}
            <li><Link href="/simulation" style={{color:'#0288d1'}}>▶ 게임 시작</Link></li>
            {/* ★ 우측 끝에 로그인/유저 정보 추가 */}
            <li className="auth-menu">
              {typeof window !== 'undefined' && localStorage.getItem('user') ? (
                <Link href="/mypage">👤 {JSON.parse(localStorage.getItem('user')).username}</Link>
              ) : (
                <Link href="/login" className="login-link">🔑 로그인</Link>
              )}
            </li>
          </ul>
        </section>
      </header>

      <div className="page-header">
        <h1>게임 밸런스 / 보정치 설정</h1>
        <p>각 스탯이 생존과 전투에 미치는 <b>영향력(가중치)</b>을 조절합니다.</p>
        <p style={{fontSize: '0.9rem', color: '#888'}}>(1.0 = 기본, 2.0 = 매우 중요, 0 = 영향 없음)</p>
      </div>

      <div className="modifiers-container">
        {Object.keys(weights).map((key) => (
          <div key={key} className="modifier-item">
            <div className="mod-label">
              <span>{statLabels[key] || key.toUpperCase()}</span>
              <span className="mod-value">{weights[key]}x</span>
            </div>
            
            <input 
              type="range" 
              min="0" max="3.0" step="0.1"
              value={weights[key]}
              onChange={(e) => handleChange(key, e.target.value)}
              className="mod-slider"
            />
            
            <div className="mod-desc">
              {weights[key] > 1.5 ? "🔥 영향력 매우 높음" : 
               weights[key] < 0.5 ? "💨 영향력 미미함" : "✨ 적절함"}
            </div>
          </div>
        ))}
      </div>
        <div className="main-save-container">
            <div className="main-save-btn" onClick={saveSettings}>
                <h1>💾 밸런스 저장</h1>
            </div>
        </div>
    </main>
  );
}