import ImportClient from './_components/ImportClient';

export const metadata = {
  title: 'Admin Import | EternalHunger',
};

export default function AdminImportPage() {
  return <ImportClient />;
}
