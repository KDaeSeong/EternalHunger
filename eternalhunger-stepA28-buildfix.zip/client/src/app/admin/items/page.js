import ItemsAdmin from './_components/ItemsAdmin';

export default function Page() {
  return <ItemsAdmin />;
}
