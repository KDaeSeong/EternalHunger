import ImportClient from '../admin/import/_components/ImportClient';

export default function Page() {
  return (
    <div style={{ maxWidth: 1100, margin: '0 auto', padding: '20px 12px' }}>
      <ImportClient />
    </div>
  );
}
